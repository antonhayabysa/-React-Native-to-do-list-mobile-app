export const todoProps = {
  id: 'id',
  isCompleted: 'isCompleted',
  name: 'name',
  category: 'category',
};
